.. _output-xref:

.. NOT REVIEWED YET

======================================================================
Xref output
======================================================================

* Printing `z`{kind} field in xref format doesn't include `kind:` prefix.
* Printing `Z`{scope} field in xref format doesn't include `scope:` prefix.
