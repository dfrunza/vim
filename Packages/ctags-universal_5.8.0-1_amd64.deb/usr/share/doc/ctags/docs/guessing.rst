.. _guessing:

======================================================================
Choosing a proper parser in ctags
======================================================================

.. IN MAN PAGE

.. contents:: `Table of contents`
	:depth: 3
	:local:

See ctags(1) within the source tree.
