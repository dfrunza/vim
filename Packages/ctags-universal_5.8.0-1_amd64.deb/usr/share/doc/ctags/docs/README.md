# Universal Ctags Documentation #

For easy reading of this documentation go to http://docs.ctags.io

## Markers ##

"NOT REVIEWED YET" means the section or block is not reviewed yet.

"IN MAN PAGE" means the topic is also explained in the man page of ctags.
